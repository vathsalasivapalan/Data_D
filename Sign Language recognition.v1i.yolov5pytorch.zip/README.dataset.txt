# Sign Language recognition > 2024-01-25 2:20am
https://universe.roboflow.com/sign-language-obhwe/sign-language-recognition-o1kt3

Provided by a Roboflow user
License: CC BY 4.0

